package utils;

public class Constants {

    public static final String GRANT_TYPE = "client_credentials";

    public static final String CONTENT_TYPE_FORM_PARAM = "application/x-www-form-urlencoded";
}
